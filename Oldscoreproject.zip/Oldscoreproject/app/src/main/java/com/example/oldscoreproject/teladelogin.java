package com.example.oldscoreproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class teladelogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.teladelogin);
    }
}